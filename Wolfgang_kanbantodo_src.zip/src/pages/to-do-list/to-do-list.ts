import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { KanbandataProvider, BacklogItem , ItemStatus} from '../../providers/kanbandata/kanbandata';
// Alles für's datum
import { DatePipe } from '@angular/common'

/**
 * Generated class for the ToDoListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-to-do-list',
  templateUrl: 'to-do-list.html',
})
export class ToDoListPage {

  //items: Array <BacklogItem>;
  todoItems: Array <BacklogItem>;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myData: KanbandataProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ToDoListPage');
  }

  ionViewWillEnter() {  //Gefilterte Backlogtabelle nach  Status == TODO
    this.todoItems = this.myData.getKanbanList().filter(item => item.status == ItemStatus.TODO);
    //this.todoItems = this.todoItems.filter(item => item.status == ItemStatus.TODO);
  }

  postpone(item) { // Punkt aus der ToDo liste wieder zurück ins Backlog
    item.status =  ItemStatus.LOGGED ;
    this.myData.saveKanbanItem(item); // in die datenbasis zurückschreiben
    this.navCtrl.setRoot(this.navCtrl.getActive().component); //frisch anzeigen
  }

  done(item) {  // Punkt ist erledigt -->  status auf "ERLEDIGT" ändern und Datum eintragen
    item.status =  ItemStatus.DONE;
    var today = Date.now(); // millis since ...
    var todayString = today.toLocaleString();
    //DatePipe.formatDate(today: number, format:"DD-MM-YYY", locale: todayString);
    item.dateDone = todayString;  // KLAPPT ALLES NICHT :-(
    //debugger;
    this.myData.saveKanbanItem(item); // in die datenbasis zurückschreiben
    this.navCtrl.setRoot(this.navCtrl.getActive().component); //frisch anzeigen
  }
}
