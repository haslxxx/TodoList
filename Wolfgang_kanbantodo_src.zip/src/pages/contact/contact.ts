// IST EIGENTLICH DIE BACKLOG LISTE ... obwohl sie noch "Contacts" heisst!!!

import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ItemDetailsPage } from '../item-details/item-details';

//Data
import { KanbandataProvider, BacklogItem ,ItemStatus } from '../../providers/kanbandata/kanbandata';

import { ScreenOrientation } from '@ionic-native/screen-orientation';


@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
  selectedItem: any;
  items: Array <BacklogItem>;
  newItem: BacklogItem;

  screenStyle = "landscape";

  constructor(public navCtrl: NavController, public myData: KanbandataProvider ,private screenOrientation: ScreenOrientation) {
    // this.items = this.myData.getKanbanList(); // Daten laden  ... geht hier nicht

    // --- initial SCREEN Orientation
    this.setScreenstyle();
    // detect orientation changes
    this.screenOrientation
      .onChange()
      .subscribe( 
          () => {
            this.setScreenstyle(); 
          // TODO  Hier wird alles aufgerufen was durch eine neuorientierung geändert werden muss
          }  
    );


    // --- Init List Data
    // this.items = this.myData.getKanbanList();  .. nützt nix ... daten noch nicht da wenn liste angezeigt wird :-(


  }

  //############### LIFECYCLE callbacks  systemcallback von IONIC!
  ionViewWillEnter() { 
    console.log("Entering Backlog ListView");
    // --- Fetch Data
    this.items = this.myData.getKanbanList();
    // while (this.myData.isDownloadReady() != true) {}; // Warteschleife bis daten geladen sind   --- GEHT NICHT
  }

  ionViewWillLeave() {

  }

  ionViewDidLoad () {

  }

  //################# Orientation
  setScreenstyle() {
    if (this.screenOrientation.type.startsWith('landscape')) {
      this.screenStyle = "landscape";
    } else {
      this.screenStyle = "portrait"; 
    };
    console.log("Orientation Changed: " + this.screenStyle);
  }
  

  //################# Click- Events
  itemSelectForTodo(item) {
    console.log("Entering itemSelectForTodo");
    item.status =  ItemStatus.TODO ;
    this.myData.saveKanbanItem(item); // in die datenbasis zurückschreiben
    this.navCtrl.setRoot(this.navCtrl.getActive().component); //frisch anzeigen
  }

  itemEdit(theItem) {
    console.log("Entering itemEdit: " + theItem.title + "  "  + theItem.id);
    this.navCtrl.push(ItemDetailsPage , {
      item: theItem
    });
  }

  itemDelete(item) {
    console.log("Entering itemDelete");
    this.myData.deleteKanbanItem(item);
    // Versuch die seite neu aufzubauen .. Klappt :-) Aber vorsicht (es killt alle navigationen davor, was in diesem fall nix ausmacht)
    this.navCtrl.setRoot(this.navCtrl.getActive().component);  
  }

  newClicked() {
    console.log("Entering newClicked");
    this.newItem = this.myData.getEmptyItem();
    this.newItem.title = ">> Please Enter New Item <<";

    this.navCtrl.push(ItemDetailsPage, {
      item: this.newItem
    });
  }
/*
  itemSelected(event, item) {
    console.log("Entering itemSelected");
  }
*/



}
