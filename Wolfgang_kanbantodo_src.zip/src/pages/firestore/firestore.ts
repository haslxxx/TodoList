import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

export interface Item { name: string; }

@Component({
  selector: 'app-root',
  template: 'firestore.html'
  /*
  template: `
    <div>
      {{ (item | async)?.name }}
    </div>
  `
  */
})
export class FirestorePage {
  private itemDoc: AngularFirestoreDocument<Item>;
  item: Observable<Item>;
  constructor(private afs: AngularFirestore) {
    debugger;
//    this.itemDoc = afs.doc<Item>('users/1');
    this.itemDoc = afs.doc<Item>('testdaten1/txDsC754Q1sDuzczfFVz');
    this.item = this.itemDoc.valueChanges();
  }
  update(item: Item) {
    this.itemDoc.update(item);
  }
}
