import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FirestorePage } from './firestore';

@NgModule({
  declarations: [
    FirestorePage,
  ],
  imports: [
    IonicPageModule.forChild(FirestorePage),
  ],
})
export class FirestorePageModule {}
