//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/toPromise';
//import { AngularFirestore } from 'angularfire2/firestore';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';


/*
  Generated class for the FirebaseProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class FirebaseProvider {

  userDoc: any;

//  constructor(public http: HttpClient, private fireStore: AngularFirestore) {
  constructor(public fireStore: AngularFirestore) {
    console.log('Hello FirebaseProvider Provider');
    debugger;
    this.userDoc = fireStore.doc<any>('testdaten1/txDsC754Q1sDuzczfFVz');
    debugger;
  }

  getFirebaseDoc() {
    return this.userDoc;
  }

}
